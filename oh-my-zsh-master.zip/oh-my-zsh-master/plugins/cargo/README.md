# cargo

This plugin adds completion for the Rust build tool [`Cargo`](https://github.com/rust-lang/cargo).

To use it, add `cargo` to the plugins array in your zshrc file:

```zsh
plugins=(... cargo)
```

Updated on March 3rd, 2019, from [Cargo 0.34.0](https://github.com/rust-lang/cargo/releases/tag/0.34.0).
