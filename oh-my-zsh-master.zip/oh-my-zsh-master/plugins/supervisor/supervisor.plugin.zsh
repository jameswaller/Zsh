# DECLARION: This plugin was created by hhatto. What I did is just making a portal from https://bitbucket.org/hhatto/zshcompfunc4supervisor.
